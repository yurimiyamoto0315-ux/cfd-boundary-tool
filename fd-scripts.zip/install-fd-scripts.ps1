﻿# FlowDesigner SSL scripts -> Documents\FlowDesigner\Scripts
# FlowDesigner libraries     -> Documents\FlowDesigner\Library
param(
  [ValidateSet('install','zip')]
  [string]$Action = 'install',
  [string]$Destination = ''
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
function Get-SslScripts {
  Get-ChildItem -LiteralPath $Root -File -Filter '*.vbs' |
    Where-Object { $_.Name -match 'SSL' }
}
function Get-FdExtTools {
  Join-Path $Root 'FdExtTools'
}
function Get-FdLibraryDir {
  Join-Path $Root 'FdLibrary'
}
function Get-FdLibraries {
  $lib = Get-FdLibraryDir
  if (-not (Test-Path -LiteralPath $lib)) { return @() }
  @(Get-ChildItem -LiteralPath $lib -File -Filter '*.fdd')
}
function Get-AirconPartsDirs {
  @(
    (Join-Path $Root '260914 Test1\02_空調班パーツ'),
    (Join-Path $Root '空調班パーツ')
  )
}
function Get-AirconParts {
  $seen = @{}
  $out = @()
  foreach ($dir in (Get-AirconPartsDirs)) {
    if (-not (Test-Path -LiteralPath $dir)) { continue }
    Get-ChildItem -LiteralPath $dir -File -Filter '*.fdd' | ForEach-Object {
      if (-not $seen.ContainsKey($_.Name)) {
        $seen[$_.Name] = $true
        $out += $_
      }
    }
  }
  @($out)
}
function Get-ScriptsDest {
  if ($Destination) { return $Destination }
  return (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'FlowDesigner\Scripts')
}
function Get-LibraryDest {
  return (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'FlowDesigner\Library')
}

function Backup-NamedFiles {
  param(
    [string]$DestDir,
    [object[]]$Files,
    [string]$Stamp
  )
  $existing = @()
  foreach ($f in @($Files)) {
    $here = Join-Path $DestDir $f.Name
    if (Test-Path -LiteralPath $here) {
      $existing += Get-Item -LiteralPath $here
    }
  }
  if ($existing.Count -lt 1) { return $null }
  $bak = Join-Path $DestDir ('_backup_' + $Stamp)
  New-Item -ItemType Directory -Force -Path $bak | Out-Null
  foreach ($f in $existing) {
    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $bak $f.Name) -Force
  }
  return $bak
}

function Install-FdScripts {
  $scripts = @(Get-SslScripts)
  $tools = Get-FdExtTools
  $libs = @(Get-FdLibraries)
  $parts = @(Get-AirconParts)
  if ($scripts.Count -lt 1) { throw "SSL の .vbs が見つかりません: $Root" }
  if (-not (Test-Path -LiteralPath $tools)) { throw "FdExtTools が見つかりません: $tools" }
  if ($libs.Count -lt 1) { throw "FdLibrary の .fdd が見つかりません: $(Get-FdLibraryDir)" }
  if ($parts.Count -lt 1) { throw "空調班パーツの .fdd が見つかりません: $((Get-AirconPartsDirs) -join ' / ')" }

  $dest = Get-ScriptsDest
  $libDest = Get-LibraryDest
  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  New-Item -ItemType Directory -Force -Path $libDest | Out-Null

  $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
  $haveOld = @(Get-ChildItem -LiteralPath $dest -File -Filter '*.vbs' -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match 'SSL' })
  $oldTools = Join-Path $dest 'FdExtTools'
  if ($haveOld.Count -gt 0 -or (Test-Path -LiteralPath $oldTools)) {
    $bak = Join-Path $dest ('_backup_' + $stamp)
    New-Item -ItemType Directory -Force -Path $bak | Out-Null
    foreach ($f in $haveOld) {
      Copy-Item -LiteralPath $f.FullName -Destination $bak -Force
    }
    if (Test-Path -LiteralPath $oldTools) {
      Copy-Item -LiteralPath $oldTools -Destination (Join-Path $bak 'FdExtTools') -Recurse -Force
    }
    Write-Host "既存スクリプトを退避しました: $bak"
  }
  $libBak = Backup-NamedFiles -DestDir $libDest -Files (@($libs) + @($parts)) -Stamp $stamp
  if ($libBak) {
    Write-Host "既存ライブラリを退避しました: $libBak"
  }

  foreach ($f in $scripts) {
    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $dest $f.Name) -Force
  }
  $destTools = Join-Path $dest 'FdExtTools'
  New-Item -ItemType Directory -Force -Path $destTools | Out-Null
  Get-ChildItem -LiteralPath $tools -Force | Where-Object { $_.Extension -ne '.bak' } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $destTools $_.Name) -Recurse -Force
  }
  foreach ($f in (@($libs) + @($parts))) {
    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $libDest $f.Name) -Force
  }

  Write-Host ''
  Write-Host 'インストール完了'
  Write-Host "スクリプト: $dest"
  Write-Host "ライブラリ: $libDest"
  Write-Host ('コピー: {0} 本の【SSL】スクリプト + FdExtTools + {1} 本のライブラリ + {2} 本の空調班パーツ' -f $scripts.Count, $libs.Count, $parts.Count)
  foreach ($f in $libs) { Write-Host ('  ' + $f.Name) }
  foreach ($f in $parts) { Write-Host ('  ' + $f.Name) }
  Write-Host 'FlowDesigner を起動し直すと、スクリプト一覧に【SSL】、ライブラリにパーツが出ます。'
  Write-Host ''
  try { Invoke-Item -LiteralPath $dest } catch {}
}

function New-FdScriptsZip {
  $scripts = @(Get-SslScripts)
  $tools = Get-FdExtTools
  $libs = @(Get-FdLibraries)
  $parts = @(Get-AirconParts)
  if ($scripts.Count -lt 1) { throw "SSL の .vbs が見つかりません: $Root" }
  if (-not (Test-Path -LiteralPath $tools)) { throw "FdExtTools が見つかりません: $tools" }
  if ($libs.Count -lt 1) { throw "FdLibrary の .fdd が見つかりません: $(Get-FdLibraryDir)" }
  if ($parts.Count -lt 1) { throw "空調班パーツの .fdd が見つかりません: $((Get-AirconPartsDirs) -join ' / ')" }

  $stage = Join-Path $env:TEMP ('fd_scripts_kit_' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $stage | Out-Null
  try {
    foreach ($f in $scripts) {
      Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $stage $f.Name) -Force
    }
    $stageTools = Join-Path $stage 'FdExtTools'
    New-Item -ItemType Directory -Force -Path $stageTools | Out-Null
    Get-ChildItem -LiteralPath $tools -Force | Where-Object { $_.Extension -ne '.bak' } | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $stageTools $_.Name) -Recurse -Force
    }
    $stageLib = Join-Path $stage 'FdLibrary'
    New-Item -ItemType Directory -Force -Path $stageLib | Out-Null
    foreach ($f in $libs) {
      Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $stageLib $f.Name) -Force
    }
    $stageParts = Join-Path $stage '空調班パーツ'
    New-Item -ItemType Directory -Force -Path $stageParts | Out-Null
    foreach ($f in $parts) {
      Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $stageParts $f.Name) -Force
    }
    foreach ($name in @('FDスクリプトをインストール.cmd','配布用ZIPを作る.cmd','install-fd-scripts.ps1','FDスクリプト_インストール.txt')) {
      $src = Join-Path $Root $name
      if (Test-Path -LiteralPath $src) {
        Copy-Item -LiteralPath $src -Destination (Join-Path $stage $name) -Force
      }
    }

    $readme = @(
      'FlowDesigner SSL スクリプトとライブラリ',
      '',
      '1. このZIPを解凍する',
      '2. 「FDスクリプトをインストール.cmd」をダブルクリック',
      '3. FlowDesigner を起動し直す',
      '4. スクリプト一覧に【SSL】… が出れば完了',
      '',
      '入れ先',
      '  スクリプト: ドキュメント\FlowDesigner\Scripts',
      '  ライブラリ: ドキュメント\FlowDesigner\Library'
    ) + @($libs | ForEach-Object { '    ' + $_.Name }) + @(
      '  空調班パーツ:'
    ) + @($parts | ForEach-Object { '    ' + $_.Name }) + @(
      '',
      '既にある同名ファイルは _backup_日時 に退避します。',
      '',
      '外気風解析・室内空調解析は FlowDesigner 付属なので、このZIPには入れていません。'
    )
    $readmeText = $readme -join "`r`n"
    $utf8bom = New-Object System.Text.UTF8Encoding $true
    [System.IO.File]::WriteAllText((Join-Path $stage 'FDスクリプト_インストール.txt'), $readmeText, $utf8bom)

    $desktop = [Environment]::GetFolderPath('Desktop')
    if (-not $desktop) { $desktop = $Root }
    $zip = Join-Path $desktop ('FDスクリプト_' + (Get-Date -Format 'yyyyMMdd') + '.zip')
    if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory($stage, $zip)
    Write-Host ''
    Write-Host '配布用ZIPを作りました'
    Write-Host $zip
    Write-Host 'これを渡せば、相手は解凍して「FDスクリプトをインストール.cmd」を押すだけです。'
    Write-Host ('ライブラリ {0} 本と空調班パーツ {1} 本も同じ操作で ドキュメント\FlowDesigner\Library へ入ります。' -f $libs.Count, $parts.Count)
    Write-Host ''
    try { Invoke-Item -LiteralPath $desktop } catch {}
  } finally {
    Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
  }
}

switch ($Action) {
  'zip' { New-FdScriptsZip }
  default { Install-FdScripts }
}
