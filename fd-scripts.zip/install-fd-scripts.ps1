﻿# FlowDesigner SSL scripts -> Documents\FlowDesigner\Scripts
# FlowDesigner libraries     -> Documents\FlowDesigner\Library
param(
  [ValidateSet('install','zip')]
  [string]$Action = 'install',
  [string]$Destination = ''
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
function Get-SslScripts {
  foreach ($name in @('【SSL】3DS外壁を発生パネルに変換.vbs','【SSL】mon結果シート作成.vbs','【SSL】オブジェクトIDカテゴライズcsv出力.vbs','【SSL】空調解析_データ読み込み.vbs','【SSL】自動化_objParamCSV読み込み.vbs','【SSL】自動化_ケーススタディ.vbs','【SSL】自動化_リスタート.vbs')) {
    Get-Item -LiteralPath (Join-Path $Root $name)
  }
}
function Get-FdExtTools {
  Join-Path $Root 'FdExtTools'
}
function Get-FdLibraryDir {
  Join-Path $Root 'FdLibrary'
}
function Get-FdLibraries {
  $lib = Get-FdLibraryDir
  if (-not (Test-Path -LiteralPath $lib)) { return @() }
  foreach ($name in @('General AC.fdd','ドア100mmメッシュ.fdd','ドア＋隙間.fdd')) {
    Get-Item -LiteralPath (Join-Path $lib $name)
  }
}
function Get-AirconPartsDirs {
  @(
    (Join-Path $Root '空調班パーツ'),
    (Join-Path $Root 'cfd_boundary_tool\assets\fdd')
  )
}
function Get-AirconParts {
  $out = @()
  $kitPath = Join-Path $Root 'cfd_boundary_tool\fd-scripts.zip'
  $kit = $null
  try {
    foreach ($name in @('エアコン.fdd','エアコン30°.fdd','エアコン50°.fdd','エアコン水平.fdd','ドア.fdd','パスファン.fdd','壁ガラリ.fdd','天井ガラリ.fdd','床スリット.fdd','引戸.fdd','開戸.fdd')) {
      $found = $null
      foreach ($dir in (Get-AirconPartsDirs)) {
        $candidate = Join-Path $dir $name
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { $found = Get-Item -LiteralPath $candidate; break }
      }
      if ($found) { $out += $found; continue }
      # Legacy templates are taken only from the fixed distribution allowlist.
      # No case-data directories, archives, or recursive source searches are used.
      if (-not $kit -and (Test-Path -LiteralPath $kitPath -PathType Leaf)) {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $kit = [System.IO.Compression.ZipFile]::OpenRead($kitPath)
      }
      $matches = @()
      if ($kit) {
        $matches = @($kit.Entries | Where-Object { $_.FullName.Replace('\','/') -ceq ('空調班パーツ/' + $name) })
      }
      if ($matches.Count -ne 1) { throw '既配布の標準パーツが不足または重複しています。標準キットを確認してください。' }
      $out += [pscustomobject]@{ Name=$name; ArchivePath=$kitPath; ArchiveEntry=$matches[0].FullName }
    }
  } finally {
    if ($kit) { $kit.Dispose() }
  }
  @($out)
}
function Copy-FdAsset {
  param([object]$Asset, [string]$Target)
  if ($Asset.ArchiveEntry) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($Asset.ArchivePath)
    try {
      $entry = $archive.GetEntry($Asset.ArchiveEntry)
      if (-not $entry) { throw '既配布の標準パーツを読み込めません。' }
      $inputStream = $entry.Open()
      try {
        $outputStream = [System.IO.File]::Create($Target)
        try { $inputStream.CopyTo($outputStream) } finally { $outputStream.Dispose() }
      } finally { $inputStream.Dispose() }
    } finally { $archive.Dispose() }
  } else {
    Copy-Item -LiteralPath $Asset.FullName -Destination $Target -Force
  }
}
function Get-FdToolFiles {
  $tools = Get-FdExtTools
  foreach ($name in @('BoundaryContract.vbs','DialogFileOpen_SSL_txt.ini','DialogOpen_SSL_monSheetExp.ini','FdExtConfig.csv','FdModelCommandList.csv','FdPropCommandList.csv','FdUtility.vbs')) {
    Get-Item -LiteralPath (Join-Path $tools $name)
  }
}
function Get-FdGuideRoot {
  foreach ($dir in @((Join-Path $Root 'cfd_boundary_tool'),$Root)) {
    if (Test-Path -LiteralPath (Join-Path $dir 'FD連携ガイド.html') -PathType Leaf) { return $dir }
  }
  throw '図解つきFD連携ガイドが見つかりません。'
}
function Get-ScriptsDest {
  if ($Destination) { return $Destination }
  return (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'FlowDesigner\Scripts')
}
function Get-LibraryDest {
  return (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'FlowDesigner\Library')
}

function Backup-NamedFiles {
  param(
    [string]$DestDir,
    [object[]]$Files,
    [string]$Stamp
  )
  $existing = @()
  foreach ($f in @($Files)) {
    $here = Join-Path $DestDir $f.Name
    if (Test-Path -LiteralPath $here) {
      $existing += Get-Item -LiteralPath $here
    }
  }
  if ($existing.Count -lt 1) { return $null }
  $bak = Join-Path $DestDir ('_backup_' + $Stamp)
  New-Item -ItemType Directory -Force -Path $bak | Out-Null
  foreach ($f in $existing) {
    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $bak $f.Name) -Force
  }
  return $bak
}

function Install-FdScripts {
  $scripts = @(Get-SslScripts)
  $tools = Get-FdExtTools
  $libs = @(Get-FdLibraries)
  $parts = @(Get-AirconParts)
  if ($scripts.Count -lt 1) { throw "SSL の .vbs が見つかりません: $Root" }
  if (-not (Test-Path -LiteralPath $tools)) { throw "FdExtTools が見つかりません: $tools" }
  if ($libs.Count -lt 1) { throw "FdLibrary の .fdd が見つかりません: $(Get-FdLibraryDir)" }
  if ($parts.Count -lt 1) { throw "空調班パーツの .fdd が見つかりません: $((Get-AirconPartsDirs) -join ' / ')" }

  $dest = Get-ScriptsDest
  $libDest = Get-LibraryDest
  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  New-Item -ItemType Directory -Force -Path $libDest | Out-Null

  $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
  $haveOld = @(Get-ChildItem -LiteralPath $dest -File -Filter '*.vbs' -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match 'SSL' })
  $oldTools = Join-Path $dest 'FdExtTools'
  if ($haveOld.Count -gt 0 -or (Test-Path -LiteralPath $oldTools)) {
    $bak = Join-Path $dest ('_backup_' + $stamp)
    New-Item -ItemType Directory -Force -Path $bak | Out-Null
    foreach ($f in $haveOld) {
      Copy-Item -LiteralPath $f.FullName -Destination $bak -Force
    }
    if (Test-Path -LiteralPath $oldTools) {
      Copy-Item -LiteralPath $oldTools -Destination (Join-Path $bak 'FdExtTools') -Recurse -Force
    }
    Write-Host "既存スクリプトを退避しました: $bak"
  }
  $libBak = Backup-NamedFiles -DestDir $libDest -Files (@($libs) + @($parts)) -Stamp $stamp
  if ($libBak) {
    Write-Host "既存ライブラリを退避しました: $libBak"
  }

  foreach ($f in $scripts) {
    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $dest $f.Name) -Force
  }
  $destTools = Join-Path $dest 'FdExtTools'
  New-Item -ItemType Directory -Force -Path $destTools | Out-Null
  foreach ($file in (Get-FdToolFiles)) {
    Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $destTools $file.Name) -Force
  }
  foreach ($f in (@($libs) + @($parts))) {
    Copy-FdAsset -Asset $f -Target (Join-Path $libDest $f.Name)
  }

  Write-Host ''
  Write-Host 'インストール完了'
  Write-Host "スクリプト: $dest"
  Write-Host "ライブラリ: $libDest"
  Write-Host ('コピー: {0} 本の【SSL】スクリプト + FdExtTools + {1} 本のライブラリ + {2} 本の空調班パーツ' -f $scripts.Count, $libs.Count, $parts.Count)
  foreach ($f in $libs) { Write-Host ('  ' + $f.Name) }
  foreach ($f in $parts) { Write-Host ('  ' + $f.Name) }
  Write-Host 'FlowDesigner を起動し直すと、スクリプト一覧に【SSL】、ライブラリにパーツが出ます。'
  Write-Host ''
  try { Invoke-Item -LiteralPath $dest } catch {}
}

function New-FdScriptsZip {
  $scripts = @(Get-SslScripts)
  $tools = Get-FdExtTools
  $libs = @(Get-FdLibraries)
  $parts = @(Get-AirconParts)
  if ($scripts.Count -lt 1) { throw "SSL の .vbs が見つかりません: $Root" }
  if (-not (Test-Path -LiteralPath $tools)) { throw "FdExtTools が見つかりません: $tools" }
  if ($libs.Count -lt 1) { throw "FdLibrary の .fdd が見つかりません: $(Get-FdLibraryDir)" }
  if ($parts.Count -lt 1) { throw "空調班パーツの .fdd が見つかりません: $((Get-AirconPartsDirs) -join ' / ')" }
  $guideRoot = Get-FdGuideRoot

  $tempRoot = [System.IO.Path]::GetFullPath((Resolve-Path -LiteralPath $env:TEMP).Path).TrimEnd('\','/')
  $stageName = 'fd_scripts_kit_' + [guid]::NewGuid().ToString('N')
  $stage = [System.IO.Path]::GetFullPath((Join-Path $tempRoot $stageName))
  if ([System.IO.Path]::GetDirectoryName($stage) -ne $tempRoot) { throw '作業フォルダを安全に作成できません。' }
  New-Item -ItemType Directory -Force -Path $stage | Out-Null
  $pendingZip = $null
  try {
    foreach ($f in $scripts) {
      Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $stage $f.Name) -Force
    }
    $stageTools = Join-Path $stage 'FdExtTools'
    New-Item -ItemType Directory -Force -Path $stageTools | Out-Null
    foreach ($file in (Get-FdToolFiles)) {
      Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $stageTools $file.Name) -Force
    }
    $stageLib = Join-Path $stage 'FdLibrary'
    New-Item -ItemType Directory -Force -Path $stageLib | Out-Null
    foreach ($f in $libs) {
      Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $stageLib $f.Name) -Force
    }
    $stageParts = Join-Path $stage '空調班パーツ'
    New-Item -ItemType Directory -Force -Path $stageParts | Out-Null
    foreach ($f in $parts) {
      Copy-FdAsset -Asset $f -Target (Join-Path $stageParts $f.Name)
    }
    Copy-Item -LiteralPath (Join-Path $guideRoot 'FD連携ガイド.html') -Destination (Join-Path $stage 'FD連携ガイド.html')
    $stageIllustrations = Join-Path $stage 'assets\setup'
    New-Item -ItemType Directory -Force -Path $stageIllustrations | Out-Null
    foreach ($name in @('fd-roundtrip.svg','fd-folder.svg','fd-rename.svg')) {
      Copy-Item -LiteralPath (Join-Path $guideRoot ('assets\setup\' + $name)) -Destination (Join-Path $stageIllustrations $name)
    }
    foreach ($name in @('FDスクリプトをインストール.cmd','配布用ZIPを作る.cmd','install-fd-scripts.ps1','FDスクリプト_インストール.txt')) {
      $src = Join-Path $Root $name
      if (Test-Path -LiteralPath $src) {
        Copy-Item -LiteralPath $src -Destination (Join-Path $stage $name) -Force
      }
    }

    $readme = @(
      'FlowDesigner SSL スクリプトとライブラリ',
      '',
      '1. このZIPを解凍する',
      '2. 「FDスクリプトをインストール.cmd」をダブルクリック',
      '3. FlowDesigner を起動し直す',
      '4. スクリプト一覧に【SSL】… が出れば完了',
      '5. 「FD連携ガイド.html」を開き、色CSVと条件CSVの受け渡しを確認する',
      '   図は assets\setup に同梱しています。ガイドと同じフォルダ構成を保ってください。',
      '',
      '入れ先',
      '  スクリプト: ドキュメント\FlowDesigner\Scripts',
      '  ライブラリ: ドキュメント\FlowDesigner\Library'
    ) + @($libs | ForEach-Object { '    ' + $_.Name }) + @(
      '  空調班パーツ:'
    ) + @($parts | ForEach-Object { '    ' + $_.Name }) + @(
      '',
      '既にある同名ファイルは _backup_日時 に退避します。',
      '',
      '外気風解析・室内空調解析は FlowDesigner 付属なので、このZIPには入れていません。'
    )
    $readmeText = $readme -join "`r`n"
    $utf8bom = New-Object System.Text.UTF8Encoding $true
    [System.IO.File]::WriteAllText((Join-Path $stage 'FDスクリプト_インストール.txt'), $readmeText, $utf8bom)

    if ($Destination) {
      $zip = [System.IO.Path]::GetFullPath($Destination)
      if ([System.IO.Path]::GetExtension($zip) -ine '.zip') { throw 'ZIP出力のDestinationには .zip のファイルパスを指定してください。' }
      $desktop = [System.IO.Path]::GetDirectoryName($zip)
      if (-not (Test-Path -LiteralPath $desktop -PathType Container)) { New-Item -ItemType Directory -Path $desktop -Force | Out-Null }
    } else {
      $desktop = [Environment]::GetFolderPath('Desktop')
      if (-not $desktop) { $desktop = $Root }
      $zip = Join-Path $desktop ('FDスクリプト_' + (Get-Date -Format 'yyyyMMdd') + '.zip')
    }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $pendingZip = Join-Path $desktop ('.fd_scripts_' + [guid]::NewGuid().ToString('N') + '.zip')
    [System.IO.Compression.ZipFile]::CreateFromDirectory($stage, $pendingZip)
    Move-Item -LiteralPath $pendingZip -Destination $zip -Force
    Write-Host ''
    Write-Host '配布用ZIPを作りました'
    Write-Host $zip
    Write-Host 'これを渡せば、相手は解凍して「FDスクリプトをインストール.cmd」を押すだけです。'
    Write-Host ('ライブラリ {0} 本と空調班パーツ {1} 本も同じ操作で ドキュメント\FlowDesigner\Library へ入ります。' -f $libs.Count, $parts.Count)
    Write-Host ''
    if (-not $Destination) { try { Invoke-Item -LiteralPath $desktop } catch {} }
  } finally {
    if ($pendingZip -and (Test-Path -LiteralPath $pendingZip -PathType Leaf)) { Remove-Item -LiteralPath $pendingZip -Force }
    # Resolve and verify our exact TEMP child before recursive cleanup.
    if (Test-Path -LiteralPath $stage -PathType Container) {
      $resolvedStage = [System.IO.Path]::GetFullPath((Resolve-Path -LiteralPath $stage).Path)
      $stageItem = Get-Item -LiteralPath $resolvedStage -Force
      if ($resolvedStage -ne $stage -or [System.IO.Path]::GetDirectoryName($resolvedStage) -ne $tempRoot -or $stageItem.Name -ne $stageName -or ($stageItem.Attributes -band [System.IO.FileAttributes]::ReparsePoint)) {
        throw '作業フォルダの検証に失敗したため、自動削除を中止しました。'
      }
      Remove-Item -LiteralPath $resolvedStage -Recurse -Force
    }
  }
}

switch ($Action) {
  'zip' { New-FdScriptsZip }
  default { Install-FdScripts }
}
