' Version: 1.1.0.0
Option Explicit

''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'' objParamCSV�ǂݍ���.vbs
'' 
'' �v���W�F�N�g�t�H���_����objParam.csv��ǂݍ����
'' �ݒ�𔽉f������
''
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''' 
' ���[�U�[�ݒ�
Dim bMsgboxDisplay
bMsgboxDisplay = TRUE	'�O������Ăяo���Ƃ��ɂ́uFALSE�v�ɕύX����

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''' 
'���ʂ̐ݒ荀��
Dim cnsFOLDERNAME, cnsCONFIGFILENAME, cnsPARAMCSVFILENAME, cnsPROCESSNAME
cnsFOLDERNAME = "FdExtTools"
cnsCONFIGFILENAME = ".\FdExtConfig.csv"
cnsPARAMCSVFILENAME = "objParam.csv"
cnsPROCESSNAME = "AklModeler.exe"

Include(".\FdUtility.vbs")		'' FlowDesigner�̕W���I�ȏ��������邽�߂̃X�N���v�g

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''' 

Dim strCsvPath, strConfFilePath
Dim ret, nProcCnt
Dim objCST, objFdUtil, objFS, objVbsUtil
Dim tsGainLog

Set objFdUtil = New CFlowDesignerUtility
Set objCST = New CFDImporter
Set objVbsUtil = New VbsUtility
Set objFS = Wscript.CreateObject("Scripting.FileSystemObject")

''''''''''''''''''''''''''''''''''''
' FD�̕����N���`�F�b�N
''''''''''''''''''''''''''''''''''''
	nProcCnt = objVbsUtil.ProcessCount(cnsPROCESSNAME)
	If nProcCnt > 1 Then
		'�����N����
		ret = Msgbox("FlowDesigner�������N�����Ă��܂��B1����FlowDesigner�𗧂��グ����Ԃł��g�p���������B", vbCritical,"�G���[")
		WScript.Quit
	ElseIf nProcCnt = 0 Then
		'FD���N�����Ă��Ȃ�
		ret = Msgbox("FlowDesigner���N�����Ă��܂���B1����FlowDesigner�𗧂��グ����Ԃł��g�p���������B", vbCritical,"�G���[")
		WScript.Quit
	End If

''''''''''''''''''''''''''''''''''''
' �ݒ�t�@�C���̓ǂݍ��݁E�v���W�F�N�g���擾
''''''''''''''''''''''''''''''''''''
	'�P���̊K�w�ɂ������Ƃ��̃p�X
	strConfFilePath = Right(cnsCONFIGFILENAME, Len(cnsCONFIGFILENAME) - 2)
	strConfFilePath = "." + Chr(92) + cnsFOLDERNAME + Chr(92) + strConfFilePath

	'FdExtConfig.csv �̓ǂݍ���
	If objFS.FileExists(cnsCONFIGFILENAME) = TRUE Then
		'�t�@�C���������K�w�ɂ����
		Call objCST.SetExtConfData(cnsCONFIGFILENAME)
	ElseIf objFS.FileExists(strConfFilePath) = TRUE Then
		'�t�@�C���������K�w�ɂȂ����
		Call objCST.SetExtConfData(strConfFilePath)
	Else
		ret = Msgbox("�ݒ�t�@�C���������ł��܂���ł����B�I�����܂��B", vbCritical,"�G���[")
		WScript.Quit
	End If

	' �v���W�F�N�g�t�H���_�̎擾
	Call objFdUtil.SetPrjInfo

	If objFdUtil.sPrjFolderPath = "" Then
		ret = Msgbox("�v���W�F�N�g�t�@�C�����J������ԂŎg�p���Ă��������B", vbCritical,"�G���[")
		WScript.Quit
	End If

	'�v���W�F�N�g�t�H���_��csv�t�@�C���p�X
	strCsvPath = objFdUtil.sPrjFolderPath + Chr(92) + cnsPARAMCSVFILENAME

''''''''''''''''''''''''''''''''''''
' objParam.csv�̓ǂݍ���
''''''''''''''''''''''''''''''''''''
	'����̊m�F���b�Z�[�W
	If bMsgboxDisplay = TRUE Then
		ret = msgbox("�v���W�F�N�g�t�H���_����objParam.csv�Őݒ��ύX���܂��B��낵���ł����H", vbOKCancel + vbInformation, "�m�F")
		If ret = vbCancel Then
			WScript.Quit
		End If
	End If

	'objParam.csv�̓ǂݍ���
	If objFS.FileExists(strCsvPath) = TRUE Then
		'csv�t�@�C���������
		Call objCST.SetObjParamList_FormatS(strCsvPath)
	Else
		'csv�t�@�C�����Ȃ����
			If bMsgboxDisplay = TRUE Then
				ret = Msgbox("objParam.csv��������܂���B", vbCritical,"�G���[")
				WScript.Quit
			End If
	End If	

	'casestudy.csv�̓��e�`�F�b�N
	'�i�[�󋵂̊m�F
	If objCST.nObjCount < 1 Then
		'�ݒ荀�ڐ���0�̂Ƃ��͏I������
		If bMsgboxDisplay = TRUE Then
			ret = Msgbox("csv���̐ݒ肪�s�����Ă��܂��B", vbCritical,"�G���[")
			WScript.Quit
		End If
	End If

''''''''''''''''''''''''''''''''''''
' �ݒ�̔��f
''''''''''''''''''''''''''''''''''''
	Set tsGainLog = FdGainOpenLog(objFdUtil)
	Call FdGainLogLine(tsGainLog, "ssl_gain_debug v=20260914s")
	Call FdGainLogLine(tsGainLog, "prj=" & FdGainAscii(objFdUtil.sPrjFolderPath))
	Call FdGainLogLine(tsGainLog, "csv=" & FdGainAscii(strCsvPath))
	Call ConvertHeatPanelTargets(objCST, objFdUtil)
	Call ConvertGainAreaTargets(objCST, objFdUtil, tsGainLog)
	Call ConvertFlowPanelTargets(objCST, objFdUtil, tsGainLog)
	WScript.Sleep 400
	Call ApplyGainAreaParams(objCST, objFdUtil, tsGainLog)
	Call ApplyFlowPanelParams(objCST, tsGainLog)
	Call MaskGainAreaParamIds(objCST, tsGainLog)
	If Not tsGainLog Is Nothing Then tsGainLog.Close
	Set tsGainLog = Nothing
	Call objCST.ObjParamAllSetting(objCST.ar_lObjID, objCST.ar_lParamID, objCST.ar_sParam)
	Call ApplyObjPriorityFromCsv(strCsvPath)

	If bMsgboxDisplay = TRUE Then
		ret = Msgbox("�ݒ肪�������܂����B", vbInformation,"����")
	End If

Set objFdUtil = Nothing
Set objCST = Nothing
Set objVbsUtil = Nothing
Set objFS = Nothing


'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


Function IsHeatPanelParamId(nId)
	If nId >= 54 And nId <= 75 Then
		IsHeatPanelParamId = True
	Else
		IsHeatPanelParamId = False
	End If
End Function

Function FdGainAscii(s)
	Dim i, c, o, ch
	o = ""
	For i = 1 To Len(CStr(s))
		ch = Mid(CStr(s), i, 1)
		c = AscW(ch)
		If c >= 32 And c <= 126 Then
			o = o & ch
		ElseIf c = 9 Or c = 10 Or c = 13 Then
			o = o & " "
		ElseIf c < 0 Then
			o = o & "[u" & Hex(c + 65536) & "]"
		Else
			o = o & "[u" & Hex(c) & "]"
		End If
	Next
	FdGainAscii = o
End Function

Function FdGainOpenLog(objFdUtil)
	Dim fso, p, ts
	Set fso = CreateObject("Scripting.FileSystemObject")
	p = ""
	If Not objFdUtil Is Nothing Then
		If objFdUtil.sPrjFolderPath <> "" Then
			p = objFdUtil.sPrjFolderPath & Chr(92) & "ssl_gain_debug.txt"
		End If
	End If
	If p = "" Then
		p = fso.GetParentFolderName(WScript.ScriptFullName) & Chr(92) & "ssl_gain_debug.txt"
	End If
	Set ts = fso.OpenTextFile(p, 2, True, False)
	Set FdGainOpenLog = ts
	Set fso = Nothing
End Function

Sub FdGainLogLine(ts, s)
	If ts Is Nothing Then Exit Sub
	ts.WriteLine CStr(s)
End Sub

Function FdGainLogSend(fd, ts, sCmd)
	Dim ret
	ret = fd.SendInstruction(sCmd)
	Call FdGainLogLine(ts, "CMD " & FdGainAscii(sCmd) & " => " & FdGainAscii(CStr(ret)))
	FdGainLogSend = ret
End Function

Sub ConvertHeatPanelTargets(objCST, objFdUtil)
	Dim i, id, typ, sSel, sDone, nHit, fd, sType
	Set fd = CreateObject("AklModeler.CommandControl")
	sType = ChrW(&H767A) & ChrW(&H751F) & ChrW(&H30D1) & ChrW(&H30CD) & ChrW(&H30EB)
	sSel = ""
	sDone = ","
	nHit = 0
	For i = 0 To objCST.nObjCount - 1
		id = objCST.ar_lObjID(i)
		If id > 0 Then
			If IsHeatPanelParamId(objCST.ar_lParamID(i)) Then
				If InStr(sDone, "," & CStr(id) & ",") = 0 Then
					sDone = sDone & CStr(id) & ","
					fd.SendInstruction "obj unselect all"
					fd.SendInstruction "obj select " & CStr(id)
					typ = CStr(fd.SendInstruction("obj get type"))
					If typ = "heatobj" Then
						If sSel <> "" Then sSel = sSel & ","
						sSel = sSel & CStr(id)
						nHit = nHit + 1
					End If
				End If
			End If
		End If
	Next
	If nHit > 0 Then
		fd.SendInstruction "obj unselect all"
		fd.SendInstruction "obj select " & sSel
		Call objFdUtil.ChangeObjType(sType)
		fd.SendInstruction "obj unselect all"
	End If
	Set fd = Nothing
End Sub


Sub ConvertGainAreaTargets(objCST, objFdUtil, tsLog)
	Dim i, id, typ, sSel, sDone, nHit, nSkip, fd, sType
	Set fd = CreateObject("AklModeler.CommandControl")
	sType = ChrW(&H767A) & ChrW(&H751F) & ChrW(&H30A8) & ChrW(&H30EA) & ChrW(&H30A2)
	sSel = ""
	sDone = ","
	nHit = 0
	nSkip = 0
	For i = 0 To objCST.nObjCount - 1
		id = objCST.ar_lObjID(i)
		If id > 0 Then
			If objCST.ar_lParamID(i) >= 76 And objCST.ar_lParamID(i) <= 78 Then
				If InStr(sDone, "," & CStr(id) & ",") = 0 Then
					sDone = sDone & CStr(id) & ","
					fd.SendInstruction "obj unselect all"
					fd.SendInstruction "obj select " & CStr(id)
					typ = LCase(Trim(CStr(fd.SendInstruction("obj get type"))))
					Call FdGainLogLine(tsLog, "CONVERT id=" & CStr(id) & " type=" & FdGainAscii(typ))
					If typ = "heatarea" Then
						nSkip = nSkip + 1
					Else
						If sSel <> "" Then sSel = sSel & ","
						sSel = sSel & CStr(id)
						nHit = nHit + 1
					End If
				End If
			End If
		End If
	Next
	Call FdGainLogLine(tsLog, "CONVERT need=" & CStr(nHit) & " skip_heatarea=" & CStr(nSkip))
	If nHit > 0 Then
		fd.SendInstruction "obj unselect all"
		fd.SendInstruction "obj select " & sSel
		Call objFdUtil.ChangeObjType(sType)
		fd.SendInstruction "obj unselect all"
		Call FdGainLogLine(tsLog, "CONVERT ChangeObjType ids=" & sSel)
	End If
	Set fd = Nothing
End Sub


Sub MaskGainAreaParamIds(objCST, tsLog)
	Dim i, pid, nMask
	nMask = 0
	For i = 0 To objCST.nObjCount - 1
		pid = objCST.ar_lParamID(i)
		If pid >= 76 And pid <= 78 Then
			Call FdGainLogLine(tsLog, "MASK remap id=" & CStr(objCST.ar_lObjID(i)) & " pid=" & CStr(pid) & " -> " & CStr(pid + 100000))
			objCST.ar_lParamID(i) = pid + 100000
			nMask = nMask + 1
		End If
	Next
	Call FdGainLogLine(tsLog, "MASK remapped=" & CStr(nMask) & " (not in FdPropCommandList, ObjParamAllSetting skips)")
End Sub

Sub FdGainSetType(fd, sType)
	Dim cnt, idx, name
	cnt = fd.SendInstruction("propertytype get count")
	If Not IsNumeric(cnt) Then Exit Sub
	For idx = 0 To CLng(cnt) - 1
		name = CStr(fd.SendInstruction("propertytype get name" & Chr(32) & CStr(idx)))
		If InStr(1, name, sType) > 0 Then
			fd.SendInstruction "propertytype set" & Chr(32) & CStr(idx)
			Exit For
		End If
	Next
End Sub

Sub ApplyGainAreaParams(objCST, objFdUtil, tsLog)
	Dim i, id, pid, sVal, k, fd
	Dim dictIds, dictType, dictCal, dictHum
	Dim sAll, sType, sUnit, sHeatJa, sHumJa
	Dim typBefore, typAfter, selRet, calAfter, humAfter, volRet, nameRet
	Dim sBare, sCmd, retSet
	Set fd = CreateObject("AklModeler.CommandControl")
	Set dictIds = CreateObject("Scripting.Dictionary")
	Set dictType = CreateObject("Scripting.Dictionary")
	Set dictCal = CreateObject("Scripting.Dictionary")
	Set dictHum = CreateObject("Scripting.Dictionary")
	sAll = ChrW(&H5168) & ChrW(&H4F53)
	sType = ChrW(&H767A) & ChrW(&H751F) & ChrW(&H30A8) & ChrW(&H30EA) & ChrW(&H30A2)
	sUnit = ChrW(&H5358) & ChrW(&H4F4D)
	sHeatJa = ChrW(&H767A) & ChrW(&H71B1) & ChrW(&H91CF)
	sHumJa = ChrW(&H767A) & ChrW(&H6E7F) & ChrW(&H91CF)
	For i = 0 To objCST.nObjCount - 1
		id = objCST.ar_lObjID(i)
		If id > 0 Then
			pid = objCST.ar_lParamID(i)
			If pid >= 76 And pid <= 78 Then
				k = CStr(id)
				sVal = Trim(CStr(objCST.ar_sParam(i)))
				If Not dictIds.Exists(k) Then dictIds.Add k, True
				If pid = 76 Then
					If dictType.Exists(k) Then dictType(k) = sVal Else dictType.Add k, sVal
				End If
				If pid = 77 Then
					If dictCal.Exists(k) Then dictCal(k) = sVal Else dictCal.Add k, sVal
				End If
				If pid = 78 Then
					If dictHum.Exists(k) Then dictHum(k) = sVal Else dictHum.Add k, sVal
				End If
			End If
		End If
	Next
	Call FdGainLogLine(tsLog, "APPLY count=" & CStr(dictIds.Count))
	fd.SendInstruction "fda set refresh disable"
	fd.SendInstruction "fda action start"
	For Each k In dictIds.Keys
		If dictType.Exists(k) Then
			sVal = dictType(k)
		Else
			sVal = sAll
		End If
		If Trim(CStr(sVal)) = "" Then sVal = sAll
		If InStr(1, CStr(sVal), sUnit) = 0 Then sVal = sAll
		Call FdGainLogLine(tsLog, "---- id=" & CStr(k))
		If dictCal.Exists(k) Then
			Call FdGainLogLine(tsLog, "CSV CALORIE=" & FdGainAscii(dictCal(k)))
		Else
			Call FdGainLogLine(tsLog, "CSV CALORIE=MISSING")
		End If
		If dictHum.Exists(k) Then Call FdGainLogLine(tsLog, "CSV HUMIDITY=" & FdGainAscii(dictHum(k)))
		Call FdGainLogSend(fd, tsLog, "obj unselect all")
		selRet = FdGainLogSend(fd, tsLog, "obj select " & CStr(k))
		typBefore = FdGainLogSend(fd, tsLog, "obj get type")
		nameRet = FdGainLogSend(fd, tsLog, "obj get name")
		volRet = FdGainLogSend(fd, tsLog, "obj get volume " & CStr(k))
		If LCase(Trim(CStr(typBefore))) <> "heatarea" Then
			Call FdGainLogLine(tsLog, "RETYPE because type=" & FdGainAscii(typBefore))
			Call FdGainSetType(fd, sType)
			WScript.Sleep 200
			typAfter = FdGainLogSend(fd, tsLog, "obj get type")
		Else
			Call FdGainLogLine(tsLog, "SKIP ChangeObjType already heatarea")
		End If
		sCmd = "property set GENCOND GENTYPE " & sVal
		Call FdGainLogSend(fd, tsLog, sCmd)
		WScript.Sleep 80
		If dictCal.Exists(k) Then
			sBare = Replace(Trim(CStr(dictCal(k))), ",", ".")
			sCmd = "property set GENCOND CALORIE " & sBare
			retSet = FdGainLogSend(fd, tsLog, sCmd)
			WScript.Sleep 80
			calAfter = FdGainLogSend(fd, tsLog, "property get GENCOND CALORIE")
			If Trim(CStr(calAfter)) = "" Or Trim(CStr(calAfter)) = "0" Or Trim(CStr(calAfter)) = "0.0" Then
				sCmd = "property set GENCOND " & sHeatJa & Chr(32) & sBare
				Call FdGainLogSend(fd, tsLog, sCmd)
				calAfter = FdGainLogSend(fd, tsLog, "property get GENCOND CALORIE")
				Call FdGainLogSend(fd, tsLog, "property get GENCOND " & sHeatJa)
			End If
			Call FdGainLogLine(tsLog, "CALORIE_AFTER=" & FdGainAscii(CStr(calAfter)))
		End If
		If dictHum.Exists(k) Then
			sBare = Replace(Trim(CStr(dictHum(k))), ",", ".")
			sCmd = "property set GENCOND HUMIDITY " & sBare
			Call FdGainLogSend(fd, tsLog, sCmd)
			humAfter = FdGainLogSend(fd, tsLog, "property get GENCOND HUMIDITY")
			If Trim(CStr(humAfter)) = "" And sBare <> "0" And sBare <> "0.0" Then
				sCmd = "property set GENCOND " & sHumJa & Chr(32) & sBare
				Call FdGainLogSend(fd, tsLog, sCmd)
				humAfter = FdGainLogSend(fd, tsLog, "property get GENCOND HUMIDITY")
			End If
			Call FdGainLogLine(tsLog, "HUMIDITY_AFTER=" & FdGainAscii(CStr(humAfter)))
		End If
		typAfter = FdGainLogSend(fd, tsLog, "obj get type")
		volRet = FdGainLogSend(fd, tsLog, "obj get volume " & CStr(k))
	Next
	fd.SendInstruction "obj unselect all"
	fd.SendInstruction "fda action end"
	fd.SendInstruction "fda set refresh enable"
	Set fd = Nothing
	Set dictIds = Nothing
	Set dictType = Nothing
	Set dictCal = Nothing
	Set dictHum = Nothing
End Sub


Function FdFlowNameEsc(s)
	Dim i, ch, o
	o = ""
	For i = 1 To Len(s)
		ch = AscW(Mid(s, i, 1))
		If ch < 0 Then ch = ch + 65536
		If ch >= 32 And ch < 127 Then
			o = o & Mid(s, i, 1)
		Else
			o = o & "[u" & Right("0000" & Hex(ch), 4) & "]"
		End If
	Next
	FdFlowNameEsc = o
End Function

Sub FdFlowForceType(fd, tsLog, sWant)
	Dim cnt, idx, name, typ, home, sNeedle, sShape
	home = -1
	If sWant = "flowinlet" Then
		sNeedle = ChrW(&H5439) & ChrW(&H51FA) & ChrW(&H53E3)
	Else
		sNeedle = ChrW(&H5438) & ChrW(&H8FBC) & ChrW(&H53E3)
	End If
	sShape = ChrW(&H5F62) & ChrW(&H72B6)
	cnt = fd.SendInstruction("propertytype get count")
	If Not IsNumeric(cnt) Then
		Call FdGainLogLine(tsLog, "FLOW types count=" & FdGainAscii(CStr(cnt)))
		Exit Sub
	End If
	For idx = 0 To CLng(cnt) - 1
		name = CStr(fd.SendInstruction("propertytype get name" & Chr(32) & CStr(idx)))
		Call FdGainLogLine(tsLog, "FLOW typename " & CStr(idx) & "=" & FdFlowNameEsc(name))
		If InStr(1, name, sShape, 1) > 0 Then home = idx
		If InStr(1, name, sNeedle, 1) > 0 Then
			fd.SendInstruction "propertytype set" & Chr(32) & CStr(idx)
			typ = LCase(Trim(CStr(fd.SendInstruction("obj get type"))))
			Call FdGainLogLine(tsLog, "FLOW set idx=" & CStr(idx) & " type=" & typ)
			If typ = sWant Then Exit Sub
		End If
	Next
	For idx = 0 To CLng(cnt) - 1
		fd.SendInstruction "propertytype set" & Chr(32) & CStr(idx)
		typ = LCase(Trim(CStr(fd.SendInstruction("obj get type"))))
		Call FdGainLogLine(tsLog, "FLOW try idx=" & CStr(idx) & " type=" & typ)
		If typ = sWant Then Exit Sub
	Next
	If home >= 0 Then fd.SendInstruction "propertytype set" & Chr(32) & CStr(home)
	Call FdGainLogLine(tsLog, "FLOW force failed want=" & sWant)
End Sub

Sub ConvertFlowPanelTargets(objCST, objFdUtil, tsLog)
	Dim i, id, pid, k, fd
	Dim dictOut, dictIn, dictGap
	Dim sOut, sIn, sGap
	Set fd = CreateObject("AklModeler.CommandControl")
	Set dictOut = CreateObject("Scripting.Dictionary")
	Set dictIn = CreateObject("Scripting.Dictionary")
	Set dictGap = CreateObject("Scripting.Dictionary")
	sOut = ChrW(&H5439) & ChrW(&H51FA) & ChrW(&H53E3)
	sIn = ChrW(&H5438) & ChrW(&H8FBC) & ChrW(&H53E3)
	sGap = ChrW(&H958B) & ChrW(&H53E3) & ChrW(&H30FB) & ChrW(&H5727) & ChrW(&H640D)
	For i = 0 To objCST.nObjCount - 1
		id = objCST.ar_lObjID(i)
		If id > 0 Then
			pid = objCST.ar_lParamID(i)
			k = CStr(id)
			If pid >= 31 And pid <= 41 Then
				If Not dictOut.Exists(k) Then dictOut.Add k, True
			ElseIf pid >= 42 And pid <= 44 Then
				If Not dictIn.Exists(k) Then dictIn.Add k, True
			ElseIf pid = 99 Then
				If Not dictGap.Exists(k) Then dictGap.Add k, True
			End If
		End If
	Next
	Call FdGainLogLine(tsLog, "FLOW out=" & CStr(dictOut.Count) & " in=" & CStr(dictIn.Count) & " gap=" & CStr(dictGap.Count))
	For Each k In dictOut.Keys
		fd.SendInstruction "obj unselect all"
		fd.SendInstruction "obj select " & CStr(k)
		Call FdFlowForceType(fd, tsLog, "flowinlet")
		Call FdGainLogLine(tsLog, "FLOW type outlet id=" & CStr(k) & " now=" & FdGainAscii(fd.SendInstruction("obj get type")))
	Next
	For Each k In dictIn.Keys
		fd.SendInstruction "obj unselect all"
		fd.SendInstruction "obj select " & CStr(k)
		Call FdFlowForceType(fd, tsLog, "flowoutlet")
		Call FdGainLogLine(tsLog, "FLOW type inlet id=" & CStr(k) & " now=" & FdGainAscii(fd.SendInstruction("obj get type")))
	Next
	For Each k In dictGap.Keys
		fd.SendInstruction "obj unselect all"
		fd.SendInstruction "obj select " & CStr(k)
		Call FdGainSetType(fd, sGap)
		Call FdGainLogLine(tsLog, "FLOW type gap id=" & CStr(k) & " now=" & FdGainAscii(fd.SendInstruction("obj get type")))
	Next
	fd.SendInstruction "obj unselect all"
	Set fd = Nothing
	Set dictOut = Nothing
	Set dictIn = Nothing
	Set dictGap = Nothing
End Sub

Function FdFlowToCmm(sVal)
	Dim n
	FdFlowToCmm = Trim(CStr(sVal))
	If Not IsNumeric(sVal) Then Exit Function
	n = CDbl(sVal)
	If n > 40 Then FdFlowToCmm = CStr(Round(n / 60, 4))
End Function

Sub ApplyFlowPanelParams(objCST, tsLog)
	Dim i, id, pid, k, sVal, fd, nMask
	Dim dictOut, dictIn, dictGap
	Dim dictFlow, dictTemp, dictHum, dictOpen
	Dim sFlowJa, sCmd
	Set fd = CreateObject("AklModeler.CommandControl")
	Set dictOut = CreateObject("Scripting.Dictionary")
	Set dictIn = CreateObject("Scripting.Dictionary")
	Set dictGap = CreateObject("Scripting.Dictionary")
	Set dictFlow = CreateObject("Scripting.Dictionary")
	Set dictTemp = CreateObject("Scripting.Dictionary")
	Set dictHum = CreateObject("Scripting.Dictionary")
	Set dictOpen = CreateObject("Scripting.Dictionary")
	sFlowJa = ChrW(&H6D41) & ChrW(&H91CF)
	For i = 0 To objCST.nObjCount - 1
		id = objCST.ar_lObjID(i)
		If id > 0 Then
			pid = objCST.ar_lParamID(i)
			k = CStr(id)
			sVal = Trim(CStr(objCST.ar_sParam(i)))
			If pid >= 31 And pid <= 41 Then
				If Not dictOut.Exists(k) Then dictOut.Add k, True
			ElseIf pid >= 42 And pid <= 44 Then
				If Not dictIn.Exists(k) Then dictIn.Add k, True
			ElseIf pid = 99 Then
				If Not dictGap.Exists(k) Then dictGap.Add k, True
			End If
			If pid = 33 Or pid = 44 Then
				If dictFlow.Exists(k) Then dictFlow(k) = sVal Else dictFlow.Add k, sVal
			ElseIf pid = 36 Then
				If dictTemp.Exists(k) Then dictTemp(k) = sVal Else dictTemp.Add k, sVal
			ElseIf pid = 37 Then
				If dictHum.Exists(k) Then dictHum(k) = sVal Else dictHum.Add k, sVal
			ElseIf pid = 99 Then
				If dictOpen.Exists(k) Then dictOpen(k) = sVal Else dictOpen.Add k, sVal
			End If
		End If
	Next
	fd.SendInstruction "fda set refresh disable"
	fd.SendInstruction "fda action start"
	For Each k In dictOut.Keys
		Call FdGainLogSend(fd, tsLog, "obj unselect all")
		Call FdGainLogSend(fd, tsLog, "obj select " & CStr(k))
		Call FdGainLogSend(fd, tsLog, "property set GENERAL INPUTTYPE " & sFlowJa)
		If dictFlow.Exists(k) Then
			sCmd = "property set GENERAL OUTLETAMOUNT " & FdFlowToCmm(dictFlow(k))
			Call FdGainLogSend(fd, tsLog, sCmd)
		End If
		If dictTemp.Exists(k) Then Call FdGainLogSend(fd, tsLog, "property set GENERAL TEMP " & dictTemp(k))
		If dictHum.Exists(k) Then Call FdGainLogSend(fd, tsLog, "property set GENERAL HUMIDITY " & dictHum(k))
	Next
	For Each k In dictIn.Keys
		Call FdGainLogSend(fd, tsLog, "obj unselect all")
		Call FdGainLogSend(fd, tsLog, "obj select " & CStr(k))
		Call FdGainLogSend(fd, tsLog, "property set GENERAL INPUTTYPE " & sFlowJa)
		If dictFlow.Exists(k) Then
			sCmd = "property set GENERAL OUTLETAMOUNT " & FdFlowToCmm(dictFlow(k))
			Call FdGainLogSend(fd, tsLog, sCmd)
		End If
	Next
	For Each k In dictGap.Keys
		Call FdGainLogSend(fd, tsLog, "obj unselect all")
		Call FdGainLogSend(fd, tsLog, "obj select " & CStr(k))
		If dictOpen.Exists(k) Then
			sVal = Trim(CStr(dictOpen(k)))
			If InStr(sVal, " ") = 0 Then sVal = sVal & " 0 2"
			sCmd = "property set GENERAL COEFF " & Chr(34) & sVal & Chr(34)
			Call FdGainLogSend(fd, tsLog, sCmd)
		End If
	Next
	fd.SendInstruction "obj unselect all"
	fd.SendInstruction "fda action end"
	fd.SendInstruction "fda set refresh enable"
	nMask = 0
	For i = 0 To objCST.nObjCount - 1
		pid = objCST.ar_lParamID(i)
		If (pid >= 31 And pid <= 44) Or pid = 99 Then
			objCST.ar_lParamID(i) = pid + 100000
			nMask = nMask + 1
		End If
	Next
	Call FdGainLogLine(tsLog, "FLOW mask=" & CStr(nMask) & " (direct property set, AllSetting skips)")
	Set fd = Nothing
	Set dictOut = Nothing
	Set dictIn = Nothing
	Set dictGap = Nothing
	Set dictFlow = Nothing
	Set dictTemp = Nothing
	Set dictHum = Nothing
	Set dictOpen = Nothing
End Sub
Sub ApplyObjPriorityFromCsv(strCsvPath)
	Const PRI_ID = 90001
	Dim fso, ts, line, parts, id, pid, pri, fd
	Set fso = CreateObject("Scripting.FileSystemObject")
	If Not fso.FileExists(strCsvPath) Then Exit Sub
	Set fd = CreateObject("AklModeler.CommandControl")
	Set ts = fso.OpenTextFile(strCsvPath, 1)
	Do While Not ts.AtEndOfStream
		line = Trim(ts.ReadLine)
		If line <> "" Then
			If Left(line, 1) <> ";" Then
				parts = Split(line, ",")
				If UBound(parts) >= 2 Then
					id = Trim(parts(0))
					pid = Trim(parts(1))
					pri = Trim(parts(2))
					If id <> "m" Then
						If IsNumeric(id) And IsNumeric(pid) Then
							If CLng(pid) = PRI_ID Then
								If IsNumeric(pri) Then
									fd.SendInstruction "obj unselect all"
									fd.SendInstruction "obj select " & CStr(CLng(id))
									fd.SendInstruction "obj set priority " & CStr(CLng(pri))
								End If
							End If
						End If
					End If
				End If
			End If
		End If
	Loop
	ts.Close
	fd.SendInstruction "obj unselect all"
	Set ts = Nothing
	Set fd = Nothing
	Set fso = Nothing
End Sub
Function Include(strFile_Inc)
	'strFile�F�ǂݍ���vbs�t�@�C���p�X

	Dim cnsFOLDERNAME
	cnsFOLDERNAME = "FdExtTools"
 
	Dim objFso_Inc, objWsh_Inc
	DIm bFlag, msg, ret, orgFileName
	Set objFso_Inc = Wscript.CreateObject("Scripting.FileSystemObject")

	bFlag = False
	'�t�@�C���̑��݊m�F
	If objFso_Inc.FileExists(strFile_Inc) = True Then
		'�t�@�C���������K�w�ɂ����

		'�O���t�@�C���̓ǂݍ���
		Set objWsh_Inc = objFso_Inc.OpenTextFile(strFile_Inc)
		ExecuteGlobal objWsh_Inc.ReadAll()
		objWsh_Inc.Close

		bFlag = True
	Else
		'�t�@�C���������K�w�ɂȂ����
		strFile_Inc = Right(strFile_Inc, Len(strFile_Inc) - 2)
		orgFileName = strFile_Inc
		strFile_Inc = "." + Chr(92) + cnsFOLDERNAME + Chr(92) + strFile_Inc

		If objFso_Inc.FileExists(strFile_Inc) = True Then
			'�O���t�@�C���̓ǂݍ���
			Set objWsh_Inc = objFso_Inc.OpenTextFile(strFile_Inc)
			ExecuteGlobal objWsh_Inc.ReadAll()
			objWsh_Inc.Close
			bFlag = True
		End If
	End If

	Set objWsh_Inc = Nothing
	Set objFso_Inc = Nothing

	'�G���[�����i�t�@�C�����Ȃ��Ƃ��ɏI������j
	If bFlag = False Then
		msg = orgFileName + "�t�@�C��������܂���ł����B"
		ret = msgbox(msg,vbCritical,"�G���[")
		WScript.Quit
	End If

End Function
