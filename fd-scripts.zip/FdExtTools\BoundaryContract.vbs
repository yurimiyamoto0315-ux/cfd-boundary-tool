' BoundaryTool CSV contract. ASCII source; no project identity or raw payload logging.
' BEGIN BOUNDARY CONTRACT
Function BoundaryUnicode(sHex)
    Dim a, x, s
    a = Split(sHex, " ") : s = ""
    For Each x In a
        s = s & ChrW(CLng("&H" & x))
    Next
    BoundaryUnicode = s
End Function

Function BoundaryMatches(s, pattern)
    Dim re
    Set re = New RegExp
    re.Pattern = pattern
    BoundaryMatches = re.Test(CStr(s))
End Function

Function BoundaryReadCp932(sPath)
    Dim stream
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2 : stream.Charset = "shift_jis" : stream.Open
    stream.LoadFromFile sPath
    BoundaryReadCp932 = stream.ReadText
    stream.Close
End Function

Function BoundaryKnownIds(sTable)
    Dim d, lines, line, a
    Set d = CreateObject("Scripting.Dictionary")
    lines = Split(Replace(Replace(sTable, vbCrLf, vbLf), vbCr, vbLf), vbLf)
    For Each line In lines
        If Trim(line) <> "" Then
            a = Split(line, ",")
            If BoundaryMatches(Trim(a(0)), "^\d+$") Then d(CStr(CLng(Trim(a(0))))) = True
        End If
    Next
    Set BoundaryKnownIds = d
End Function

Function BoundaryNumber(s, ByRef n)
    BoundaryNumber = False
    If Not BoundaryMatches(s, "^[+-]?([0-9]+(\.[0-9]*)?|\.[0-9]+)([eE][+-]?[0-9]+)?$") Then Exit Function
    On Error Resume Next
    Err.Clear
    n = CDbl(s)
    If Err.Number = 0 Then BoundaryNumber = True
    Err.Clear
    On Error GoTo 0
End Function

Function BoundaryValueValid(oid, pid, s)
    Dim n, a, i
    BoundaryValueValid = False
    If Len(s) = 0 Or InStr(s, Chr(34)) > 0 Or InStr(s, Chr(0)) > 0 Or InStr(s, vbTab) > 0 Then Exit Function
    If Not ((oid <> "m" And (pid = 25 Or pid = 62)) Or (oid = "m" And pid = 80001)) Then
        Select Case LCase(s)
            Case "nan", "inf", "+inf", "-inf", "infinity", "+infinity", "-infinity"
                Exit Function
        End Select
        If BoundaryMatches(s, "^[+-]?([0-9]+(\.[0-9]*)?|\.[0-9]+)([eE][+-]?[0-9]+)?$") Then
            If Not BoundaryNumber(s, n) Then Exit Function
            If Abs(n) > 3.402823E38 Then Exit Function
        End If
    End If
    If pid = 99 And oid <> "m" Then
        a = Split(s, " ")
        If UBound(a) <> 0 And UBound(a) <> 2 Then Exit Function
        For i = 0 To UBound(a)
            If Not BoundaryNumber(a(i), n) Then Exit Function
            If n < 0 Then Exit Function
            If i = 0 And n > 100 Then Exit Function
        Next
        BoundaryValueValid = True : Exit Function
    End If
    If oid = "m" Then
        Select Case pid
            Case 3, 8, 5304, 5305, 5306
                If Not BoundaryNumber(s, n) Then Exit Function
                If pid = 3 And n < -273.15 Then Exit Function
                If (pid = 8 Or pid = 5304) And (n < 0 Or n > 100) Then Exit Function
                If pid = 5305 And n <= 0 Then Exit Function
                If pid = 5306 And n < 0 Then Exit Function
        End Select
    Else
        If pid = 0 And s <> "0" And s <> "1" Then Exit Function
        If pid = 1 Then
            If s <> BoundaryUnicode("8003 616E 3057 306A 3044 FF08 969C 5BB3 7269 FF09") And s <> BoundaryUnicode("6D41 4F53") And s <> BoundaryUnicode("56FA 4F53 FF08 7269 6027 FF09") Then Exit Function
        End If
        If pid = 61 Then
            If s <> BoundaryUnicode("306F 3044") And s <> BoundaryUnicode("3044 3044 3048") Then Exit Function
        End If
        Select Case pid
            Case 3, 24, 26, 27, 32, 33, 36, 37, 43, 44, 55, 56, 57, 58, 59, 60, 63, 64, 65, 67, 68, 69, 70, 71, 77, 78, 90001
                If Not BoundaryNumber(s, n) Then Exit Function
                Select Case pid
                    Case 3, 36, 55, 57, 65
                        If n < -273.15 Then Exit Function
                    Case 24, 26, 58, 63
                        If n <= 0 Then Exit Function
                    Case 37
                        If n < 0 Or n > 100 Then Exit Function
                    Case 27, 56, 64
                        ' Signed surface/material heat is allowed.
                    Case 90001
                        If n < 0 Or n > 2147483647 Then Exit Function
                        If n <> Fix(n) Then Exit Function
                    Case Else
                        If n < 0 Then Exit Function
                End Select
        End Select
    End If
    BoundaryValueValid = True
End Function

Function BoundaryCstMatchesCsv(cst, sText)
    Dim lines, line, a, stage, n, oid
    BoundaryCstMatchesCsv = False : stage = 0 : n = 0
    lines = Split(Replace(Replace(sText, vbCrLf, vbLf), vbCr, vbLf), vbLf)
    For Each line In lines
        line = Trim(line)
        If line <> "" Then
            If stage = 0 Then
                If Left(line, 1) <> ";" Then stage = 1
            ElseIf stage = 1 Then
                stage = 2
            Else
                a = Split(line, ",")
                If n >= cst.nObjCount Then Exit Function
                oid = Trim(a(0))
                If oid = "m" Or oid = "-1" Then oid = -1 Else oid = CLng(oid)
                If cst.ar_lObjID(n) <> oid Or cst.ar_lParamID(n) <> CLng(Trim(a(1))) Then Exit Function
                If Trim(CStr(cst.ar_sParam(n))) <> Trim(a(2)) Then Exit Function
                cst.ar_sParam(n) = Trim(a(2))
                n = n + 1
            End If
        End If
    Next
    If n = cst.nObjCount And stage = 2 Then BoundaryCstMatchesCsv = True
End Function

Function BoundaryCheckedSend(fd, command)
    Dim result, op
    result = fd.SendInstruction(command)
    op = LCase(Trim(command))
    If Left(op, 11) = "obj select " Or Left(op, 8) = "obj set " Or Left(op, 13) = "property set " Or Left(op, 18) = "property setmulti " Or Left(op, 17) = "propertytype set " Then
        If VarType(result) = vbBoolean Then
            If Not result Then Err.Raise vbObjectError + 512, "BoundaryTool", "E_FD_COMMAND"
        End If
        If VarType(result) = vbString Then
            If BoundaryMatches(LCase(result), "^(error|failed|false)([: ].*)?$") Then Err.Raise vbObjectError + 512, "BoundaryTool", "E_FD_COMMAND"
        End If
    End If
    BoundaryCheckedSend = result
End Function

Function BoundaryFailureRecord(stage, target, pid)
    If Not BoundaryMatches(stage, "^[A-Z_]+$") Then stage = "UNKNOWN"
    If Not BoundaryMatches(CStr(target), "^(m|[0-9]+(,[0-9]+)*)$") Then target = "0"
    If Not BoundaryMatches(CStr(pid), "^[0-9]+$") Then pid = 0
    BoundaryFailureRecord = "status=FAILED_PARTIAL_POSSIBLE" & vbCrLf & "code=E_FD_APPLY" & vbCrLf & _
        "stage=" & stage & vbCrLf & "object_ids=" & CStr(target) & vbCrLf & "parameter_id=" & CStr(pid) & vbCrLf
End Function

Function BoundaryHasRows(rows, oid, pids)
    Dim p
    BoundaryHasRows = False
    For Each p In Split(pids, " ")
        If Not rows.Exists(oid & ":" & p) Then Exit Function
    Next
    BoundaryHasRows = True
End Function

Function BoundaryRequiredRows(rows, ids)
    Dim oid, s, needs
    BoundaryRequiredRows = ""
    For Each oid In ids.Keys
        If rows.Exists(oid & ":54") Then
            s = rows(oid & ":54") : needs = ""
            Select Case s
                Case BoundaryUnicode("8868 9762 6E29 5EA6 56FA 5B9A")
                    needs = "55"
                Case BoundaryUnicode("8868 9762 7DCF 767A 71B1 91CF"), BoundaryUnicode("5358 4F4D 9762 7A4D 3042 305F 308A 767A 71B1 91CF")
                    needs = "56"
                Case BoundaryUnicode("5916 6C17 6E29 3068 71B1 901A 904E 7387"), BoundaryUnicode("5916 6C17 6E29 3068 5185 5074 8868 9762 307E 3067 306E 71B1 901A 904E 7387")
                    needs = "57 58"
                Case BoundaryUnicode("5916 6C17 6E29 3068 56FA 4F53 8868 9762 307E 3067 306E 71B1 4F1D 9054 7387")
                    needs = "57 59 60 61"
                Case Else
                    BoundaryRequiredRows = "E_PANEL_MODE" : Exit Function
            End Select
            If Not BoundaryHasRows(rows, oid, needs) Then BoundaryRequiredRows = "E_REQUIRED_PANEL" : Exit Function
        End If
        If rows.Exists(oid & ":61") Then
            If rows(oid & ":61") = BoundaryUnicode("306F 3044") Then
                If Not BoundaryHasRows(rows, oid, "62 63") Then BoundaryRequiredRows = "E_REQUIRED_THICKNESS" : Exit Function
            End If
        End If
        If rows.Exists(oid & ":23") Then
            s = rows(oid & ":23")
            If s = BoundaryUnicode("539A 307F 3092 8003 616E") Then
                If Not BoundaryHasRows(rows, oid, "25 26") Then BoundaryRequiredRows = "E_REQUIRED_MATERIAL" : Exit Function
            ElseIf s = BoundaryUnicode("71B1 901A 904E 7387") Then
                If Not BoundaryHasRows(rows, oid, "24") Then BoundaryRequiredRows = "E_REQUIRED_U" : Exit Function
            ElseIf s <> BoundaryUnicode("8003 616E 3057 306A 3044 FF08 65AD 71B1 FF09") Then
                BoundaryRequiredRows = "E_MATERIAL_MODE" : Exit Function
            End If
        End If
        If rows.Exists(oid & ":31") Then
            s = rows(oid & ":31")
            If s = BoundaryUnicode("6D41 91CF") Then
                If Not BoundaryHasRows(rows, oid, "33 36 37") Then BoundaryRequiredRows = "E_REQUIRED_SUPPLY" : Exit Function
            Else
                BoundaryRequiredRows = "E_FLOW_MODE" : Exit Function
            End If
        End If
        If rows.Exists(oid & ":42") Then
            s = rows(oid & ":42")
            If s = BoundaryUnicode("6D41 91CF") Then
                If Not BoundaryHasRows(rows, oid, "44") Then BoundaryRequiredRows = "E_REQUIRED_RETURN" : Exit Function
            Else
                BoundaryRequiredRows = "E_FLOW_MODE" : Exit Function
            End If
        End If
        If rows.Exists(oid & ":76") Then
            s = rows(oid & ":76")
            If s <> BoundaryUnicode("5168 4F53") And s <> BoundaryUnicode("5358 4F4D 4F53 7A4D 3042 305F 308A") Then BoundaryRequiredRows = "E_GAIN_MODE" : Exit Function
            If Not BoundaryHasRows(rows, oid, "77 78") Then BoundaryRequiredRows = "E_REQUIRED_GAIN" : Exit Function
        End If
    Next
End Function

Function BoundaryValidateCsv(sText, sPropList, sModelList, ByRef sUnit, ByRef bFlow, ByRef dIds)
    Dim propIds, modelIds, rows, families, familyCount, lines, line, a, i, stage, oid, pid, key, value, family, reason
    Set propIds = BoundaryKnownIds(sPropList) : Set modelIds = BoundaryKnownIds(sModelList)
    Set rows = CreateObject("Scripting.Dictionary") : Set families = CreateObject("Scripting.Dictionary")
    Set familyCount = CreateObject("Scripting.Dictionary")
    Set dIds = CreateObject("Scripting.Dictionary")
    sUnit = "" : bFlow = False : stage = 0 : reason = ""
    lines = Split(Replace(Replace(sText, vbCrLf, vbLf), vbCr, vbLf), vbLf)
    For i = 0 To UBound(lines)
        line = Trim(lines(i))
        If line <> "" Then
            If stage = 0 And Left(line, 1) = ";" Then
                If InStr(line, "flow_unit=") > 0 Then
                    If sUnit <> "" Or Not BoundaryMatches(line, "^; cfd_boundary_tool contract=1 flow_unit=(cmh|cmm),,$") Then reason = "E_UNIT" : Exit For
                    If InStr(line, "flow_unit=cmh") > 0 Then sUnit = "cmh" Else sUnit = "cmm"
                End If
            Else
                a = Split(line, ",")
                If UBound(a) <> 2 Or InStr(line, Chr(34)) > 0 Then reason = "E_THREE_COLUMNS" : Exit For
                If stage = 0 Then
                    If a(0) <> BoundaryUnicode("25CF 30C7 30FC 30BF 958B 59CB 884C") Or a(1) <> "=" Or a(2) <> "=" Then reason = "E_CP932_MARKER" : Exit For
                    stage = 1
                ElseIf stage = 1 Then
                    If line <> BoundaryUnicode("30AA 30D6 30B8 30A7 30AF 30C8 0049 0044 002C 30D1 30E9 30E1 30FC 30BF 0049 0044 002C 30D1 30E9 30E1 30FC 30BF") Then reason = "E_HEADER" : Exit For
                    stage = 2
                Else
                    oid = Trim(a(0)) : value = Trim(a(2))
                    If oid = "-1" Then oid = "m"
                    If oid <> "m" Then
                        If Not BoundaryMatches(oid, "^[0-9]+$") Then reason = "E_OBJECT_ID" : Exit For
                        If Len(oid) > 10 Then reason = "E_OBJECT_ID" : Exit For
                        If CDbl(oid) < 1 Or CDbl(oid) > 2147483647 Then reason = "E_OBJECT_ID" : Exit For
                        oid = CStr(CLng(oid)) : dIds(oid) = True
                    End If
                    If Not BoundaryMatches(Trim(a(1)), "^[0-9]+$") Then reason = "E_PARAM_ID" : Exit For
                    If Len(Trim(a(1))) > 10 Then reason = "E_PARAM_ID" : Exit For
                    If CDbl(Trim(a(1))) > 2147483647 Then reason = "E_PARAM_ID" : Exit For
                    pid = CLng(Trim(a(1)))
                    If oid = "m" Then
                        If Not modelIds.Exists(CStr(pid)) Then reason = "E_UNKNOWN_MODEL_PARAM" : Exit For
                    Else
                        If Not propIds.Exists(CStr(pid)) And pid <> 90001 Then reason = "E_UNKNOWN_OBJECT_PARAM" : Exit For
                    End If
                    If Not BoundaryValueValid(oid, pid, value) Then reason = "E_VALUE" : Exit For
                    If oid <> "m" And ((pid >= 31 And pid <= 44) And pid <> 31 And pid <> 33 And pid <> 36 And pid <> 37 And pid <> 42 And pid <> 44) Then reason = "E_UNSUPPORTED_FLOW_PARAM" : Exit For
                    key = oid & ":" & CStr(pid)
                    If rows.Exists(key) Then reason = "E_DUPLICATE_PARAM" : Exit For
                    rows(key) = value
                    If oid <> "m" Then
                        family = ""
                        If pid >= 54 And pid <= 75 Then family = "54"
                        If pid >= 23 And pid <= 27 Then family = "23"
                        If pid >= 31 And pid <= 41 Then family = "31"
                        If pid >= 42 And pid <= 44 Then family = "42"
                        If pid >= 76 And pid <= 78 Then family = "76"
                        If pid = 1 Then family = "1"
                        If pid = 99 Then family = "99"
                        If family <> "" Then families(oid & ":" & family) = True
                        If pid = 33 Or pid = 44 Then bFlow = True
                    End If
                End If
            End If
        ElseIf stage = 1 Or (stage = 2 And i < UBound(lines)) Then
            reason = "E_BLANK_DATA_ROW" : Exit For
        End If
    Next
    If reason <> "" Then BoundaryValidateCsv = "line " & CStr(i + 1) & " " & reason : Exit Function
    If stage <> 2 Then BoundaryValidateCsv = "E_CP932_MARKER_HEADER" : Exit Function
    If dIds.Count = 0 Then BoundaryValidateCsv = "E_NO_OBJECTS" : Exit Function
    For Each key In families.Keys
        If Not rows.Exists(key) Then BoundaryValidateCsv = "E_REQUIRED_MODE" : Exit Function
        a = Split(key, ":") : oid = a(0)
        If Not familyCount.Exists(oid) Then familyCount(oid) = 0
        familyCount(oid) = familyCount(oid) + 1
        If familyCount(oid) > 1 Then BoundaryValidateCsv = "E_CONFLICTING_MODES" : Exit Function
    Next
    BoundaryValidateCsv = BoundaryRequiredRows(rows, dIds)
End Function

Function BoundaryLiveIds(fd, expectedIds)
    Dim before, allIds, token, tokens, actual, id
    BoundaryLiveIds = ""
    before = CStr(fd.SendInstruction("obj get id"))
    fd.SendInstruction "obj unselect all"
    fd.SendInstruction "obj select all"
    allIds = CStr(fd.SendInstruction("obj get id"))
    fd.SendInstruction "obj unselect all"
    If BoundaryMatches(before, "^[0-9]+(\s*,\s*[0-9]+)*$") Then fd.SendInstruction "obj select " & before
    Set actual = CreateObject("Scripting.Dictionary")
    tokens = Split(Replace(allIds, " ", ""), ",")
    For Each token In tokens
        If Not BoundaryMatches(token, "^[0-9]+$") Then BoundaryLiveIds = "E_FD_OBJECT_LIST" : Exit Function
        If Len(token) > 10 Then BoundaryLiveIds = "E_FD_OBJECT_LIST" : Exit Function
        If CDbl(token) < 1 Or CDbl(token) > 2147483647 Then BoundaryLiveIds = "E_FD_OBJECT_LIST" : Exit Function
        actual(CStr(CLng(token))) = True
    Next
    For Each id In expectedIds.Keys
        If Not actual.Exists(id) Then BoundaryLiveIds = "E_OBJECT_NOT_IN_PROJECT id=" & id : Exit Function
    Next
End Function
' END BOUNDARY CONTRACT
