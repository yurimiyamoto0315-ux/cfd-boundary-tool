@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-fd-scripts.ps1" -Action install
echo.
pause
exit /b %ERRORLEVEL%
